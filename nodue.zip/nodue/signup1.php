<?php
$link = mysqli_connect("localhost", "root", "123456", "nodue") or die("Connection Error");
$fname=$_POST['firstname'];
$lname=$_POST['lastname'];
$sid=$_POST['username'];
$password=$_POST['password'];
$dob=$_POST['DOB'];
$branch=$_POST['branch'];
$batch=$_POST['batch'];
$mobile=$_POST['mobile'];
$cpassword=$_POST['cpassword'];
if ($password==$cpassword){
$q1= "insert into register (fname,lname,sid,password,DOB,branch,batch,mobile) values ('$fname','$lname','$sid','$password','$dob','$branch','$batch','$mobile')";
$result=mysqli_query($link,$q1) or die('SQL QUERY');
if($result)
{
$q2 = "insert into studentlogin(username,password) values('$sid','$password')";
$result1=mysqli_query($link,$q2) or die('Error in SQL INNER QUERY');
echo "<script>alert('Registeration complete!'); window.location.href = 'Home.html';</script>";
echo "<br />";
}
}
?>	

