<html>
    <head>
        <title>Clear Form</title>
        <style>
            body{
                color: darkmagenta;
                background: #4CAF50;
            }
            form{
                background: white;
               
            }
            form input, form select, form button {
  width: 248px;
  border: 1px solid;
  border-bottom-color: rgba(255,255,255,.5);
  border-right-color: rgba(60,60,60,.35);
  border-top-color: rgba(60,60,60,.35);
  border-left-color: rgba(80,80,80,.45);
  background-color: rgba(0,0,0,.2);
  background-repeat: no-repeat;
  padding: 8px 24px 8px 10px;
  font: bold .875em/1.25em "Lucida Sans", sans-serif;
  letter-spacing: .075em;
  color: #fff;
  text-shadow: 0 1px 0 rgba(0,0,0,.1);
  margin-bottom: 5px;
}
            form input{
                background: darkgrey;
            }
            form button[type=button]{
                width: 40px;
                margin-bottom: 0px;
                color: #497694;
                letter-spacing: .05em;
                text-shadow: 0 1px 0 #133d3e;
                text-transform: uppercase;
                background: #04223a;
                border-top-color: #9fb5b5;
                border-left-color: #608586;
                border-bottom-color: #1b4849;
                border-right-color: #1e4d4e;
                cursor: pointer;
                
            }
            .button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 18px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 6px 10px;
    cursor: pointer;
}
        </style>
    </head>
    <body>
        <h3 align="center"><u>NO DUE MANAGEMENT SYSTEM</u></h3>
        <div align="center">
        <form method="POST" action="issue.php" >
        <input type="submit" name="submit" value="Issue" /> 
            </form></div><br/>
        <div align="center">
        <form method="POST" action="due.php" >
        <input type="submit" name="submit" value="Due Report" />                                                                                
            </form></div>s
            <br />
         <div align="center">
        <form method="POST" action="clear.php" >
        <input type="submit" name="submit" value="Clear Due" />                                                                                    </form>
        </div>
    </body>
</html>