<?php
session_start();
$_SESSION["logged_id"]=0;
$link = mysqli_connect("localhost", "root", "123456", "nodue") or die("Connection Error");
$username=$_POST['username'];
$password=$_POST['password'];
$query="select password from admin where username= '$username'";
$res=mysqli_query($link,$query) or die("ERROR");
$r=mysqli_fetch_array($res);
if($r[0]==$password){
session_start();
$_SESSION["username"]=$username;
$_SESSION["logged_id"]=1;
header("location:clearForm.html");
}
elseif($r[0]==NULL)
{
die("invalid user");
}
else
{
die ("invalid password");
}
?>
