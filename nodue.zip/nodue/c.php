<?php
$a="localhost";
$b="root";
$c="";
$d="nodue";
$db=mysqli_connect($a,$b,$c,$d) or die("error");
echo "Successfully connected";
?>